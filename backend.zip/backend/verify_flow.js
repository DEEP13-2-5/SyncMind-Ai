// Native fetch is used

const BASE_URL = 'http://localhost:8080/api';
const UNIQUE_ID = Date.now();
const USER = {
    username: `user_${UNIQUE_ID}`,
    email: `user_${UNIQUE_ID}@test.com`,
    password: 'password123'
};

// Helper to get a fresh token
async function getFreshToken(label) {
    const id = Date.now() + Math.random();
    const user = { username: `u_${id}`, email: `u_${id}@test.com`, password: 'password123' };

    await fetch(`${BASE_URL}/auth/signup`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(user)
    });

    const login = await fetch(`${BASE_URL}/auth/login`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: user.email, password: user.password })
    });
    const data = await login.json();
    console.log(`[${label}] Fresh Token Obtained.`);
    return data.token;
}

async function test() {
    // 1. Test Load Test Route
    console.log("\n--> 1. Testing /api/load-test (Fresh User)");
    const token1 = await getFreshToken("LoadTest");

    // We use a short duration "3s" to make the test faster for verification
    const loadTest = await fetch(`${BASE_URL}/load-test`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': token1 },
        body: JSON.stringify({ testURL: 'http://example.com' }) // Uses default settings but maybe we can override in server if allowed, or just wait 30s
        // Note: server hardcodes "30s" in Load.js line 27. I can't change it from here without changing server code.
        // I will wait.
    });

    console.log("Load Test HTTP Status:", loadTest.status);
    if (loadTest.status !== 200) {
        console.error("Load Test Failed:", await loadTest.text());
        return;
    }

    const loadData = await loadTest.json();
    console.log("--> LOAD METRICS RECEIVED:");
    console.log(JSON.stringify(loadData.metrics, null, 2));

    const sessionID = loadData.sessionId;
    console.log(`\nSession ID: ${sessionID}`);

    // 2. Test Agentic AI (Chat)
    console.log("\n--> 2. Testing AI Chat (using Session ID)");
    const token2 = await getFreshToken("ChatTest");

    // Chat uses the same token (or we can use fresh one if we share session? No, session is global memory).
    // Let's use the same token since that user owns the credit (well, actually logic doesn't check owner of session yet, just credit)

    const chatTest = await fetch(`${BASE_URL}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': token2 },
        body: JSON.stringify({
            sessionId: sessionID,
            message: 'Analyze the p95 latency for me.'
        })
    });

    console.log("Chat HTTP Status:", chatTest.status);
    const chatData = await chatTest.json();

    console.log("--> AI RESPONSE:");
    console.log(chatData.reply);

    // 3. Test Payment Initiation
    console.log("\n--> 3. Testing Payment (Requires RAZORPAY KEYS)");
    // Payment does not depend on credits. It creates an order for a plan.
    // We can use token2 (who has 1 credit) or token1 (who has 0). It doesn't matter.
    // Let's use token1.

    try {
        const pay = await fetch(`${BASE_URL}/payment/create-sub`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token1
            },
            body: JSON.stringify({ planType: 'weekly' })
        });
        console.log("Payment Init Status:", pay.status);
        const payData = await pay.json();
        console.log("Payment Response:", payData);

        if (pay.status === 200 && payData.orderId) {
            console.log("SUCCESS: Razorpay Order Created!");
        } else {
            console.log("FAILURE: Could not create order (Check Keys?)");
        }
    } catch (e) {
        console.log("Payment Logic Error:", e.message);
    }
}

test();
